-- =============================================================================
-- ApprovLinq Invoice Scanner Service — Complete Database Schema
-- Safe to run on a fresh database OR an existing one.
-- All statements are idempotent: CREATE IF NOT EXISTS, ADD COLUMN IF NOT EXISTS.
-- NO dollar-quoted DO blocks — compatible with all SQL editors including Neon.
-- =============================================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------------
-- TENANTS
-- ---------------------------------------------------------------------------
create table if not exists tenants (
    id           uuid        primary key default gen_random_uuid(),
    tenant_code  varchar(100) unique not null,
    tenant_name  varchar(255) not null,
    status       varchar(30)  not null default 'active',
    is_active    boolean      not null default true,
    contact_name varchar(255),
    contact_email varchar(255),
    notes        text,
    scan_mode    varchar(20)  not null default 'summary',
    created_at   timestamptz  not null default now(),
    updated_at   timestamptz  not null default now()
);

-- Back-fill column added after initial release
alter table tenants add column if not exists scan_mode varchar(20) not null default 'summary';


-- ---------------------------------------------------------------------------
-- USERS
-- ---------------------------------------------------------------------------
create table if not exists users (
    id            uuid        primary key default gen_random_uuid(),
    email         varchar(255) unique not null,
    full_name     varchar(255) not null,
    password_hash text         not null,
    role          varchar(30)  not null default 'tenant',
    is_active     boolean      not null default true,
    created_at    timestamptz  not null default now(),
    updated_at    timestamptz  not null default now()
);


-- ---------------------------------------------------------------------------
-- USER ↔ TENANT ASSIGNMENTS
-- ---------------------------------------------------------------------------
create table if not exists user_tenants (
    id          bigserial    primary key,
    user_id     uuid         not null references users(id)   on delete cascade,
    tenant_id   uuid         not null references tenants(id) on delete cascade,
    tenant_role varchar(30)  not null default 'tenant_admin',
    is_default  boolean      not null default false,
    created_at  timestamptz  not null default now(),
    constraint uq_user_tenant unique (user_id, tenant_id)
);


-- ---------------------------------------------------------------------------
-- USER SESSIONS
-- ---------------------------------------------------------------------------
create table if not exists user_sessions (
    id         bigserial   primary key,
    user_id    uuid        not null references users(id) on delete cascade,
    token_hash varchar(64) unique not null,
    expires_at timestamptz not null,
    created_at timestamptz not null default now(),
    revoked_at timestamptz
);


-- ---------------------------------------------------------------------------
-- COMPANIES  (one tenant can have multiple legal entities / company books)
-- ---------------------------------------------------------------------------
create table if not exists companies (
    id                  uuid        primary key default gen_random_uuid(),
    tenant_id           uuid        not null references tenants(id) on delete cascade,
    company_code        varchar(100) not null,
    company_name        varchar(255) not null,
    registration_number varchar(100),
    vat_number          varchar(100),
    is_active           boolean      not null default true,
    created_at          timestamptz  not null default now(),
    updated_at          timestamptz  not null default now(),
    constraint uq_tenant_company_code unique (tenant_id, company_code)
);


-- ---------------------------------------------------------------------------
-- TENANT SUPPLIERS  (supplier master list per tenant + company)
-- ---------------------------------------------------------------------------
create table if not exists tenant_suppliers (
    id                    bigserial    primary key,
    tenant_id             uuid         not null references tenants(id)   on delete cascade,
    company_id            uuid         references companies(id) on delete cascade,
    supplier_account_code varchar(100),
    supplier_name         varchar(255) not null,
    default_nominal       varchar(100),
    posting_account       varchar(100) not null default '',
    is_active             boolean      not null default true,
    created_at            timestamptz  not null default now(),
    updated_at            timestamptz  not null default now()
);

-- Back-fill columns added after initial release (safe on existing DBs)
alter table tenant_suppliers add column if not exists company_id           uuid references companies(id) on delete cascade;
alter table tenant_suppliers add column if not exists supplier_account_code varchar(100);
alter table tenant_suppliers add column if not exists default_nominal       varchar(100);

-- Partial unique index on account code (NULL rows excluded)
create unique index if not exists ix_tenant_suppliers_tenant_company_account_code
    on tenant_suppliers(tenant_id, company_id, supplier_account_code)
    where supplier_account_code is not null;


-- ---------------------------------------------------------------------------
-- TENANT NOMINAL ACCOUNTS  (chart of accounts per tenant + company)
-- ---------------------------------------------------------------------------
create table if not exists tenant_nominal_accounts (
    id           bigserial    primary key,
    tenant_id    uuid         not null references tenants(id)   on delete cascade,
    company_id   uuid         references companies(id) on delete cascade,
    account_code varchar(100) not null,
    account_name varchar(255) not null,
    is_active    boolean      not null default true,
    is_default   boolean      not null default false,
    created_at   timestamptz  not null default now(),
    updated_at   timestamptz  not null default now(),
    constraint uq_tenant_company_nominal_account_code
        unique (tenant_id, company_id, account_code)
);

-- Back-fill columns added after initial release
alter table tenant_nominal_accounts add column if not exists company_id  uuid references companies(id) on delete cascade;
alter table tenant_nominal_accounts add column if not exists is_default  boolean not null default false;


-- ---------------------------------------------------------------------------
-- ISSUE LOGS  (manual / auto-generated review flags)
-- ---------------------------------------------------------------------------
create table if not exists issue_logs (
    id                  bigserial   primary key,
    tenant_id           uuid        not null references tenants(id) on delete cascade,
    created_by_user_id  uuid        references users(id) on delete set null,
    title               varchar(255) not null,
    description         text         not null,
    status              varchar(30)  not null default 'pending',
    priority            varchar(20)  not null default 'normal',
    resolution_notes    text,
    created_at          timestamptz  not null default now(),
    updated_at          timestamptz  not null default now()
);


-- ---------------------------------------------------------------------------
-- INVOICE BATCHES  (one batch = one uploaded PDF, potentially many pages)
-- ---------------------------------------------------------------------------
create table if not exists invoice_batches (
    id              uuid        primary key default gen_random_uuid(),
    tenant_id       uuid        references tenants(id)   on delete set null,
    company_id      uuid        references companies(id) on delete set null,
    batch_name      varchar(255) not null,
    source_filename varchar(500),
    status          varchar(50)  not null default 'created',
    page_count      integer,
    notes           text,
    scan_mode       varchar(20)  not null default 'summary',
    created_at      timestamptz  not null default now(),
    processed_at    timestamptz
);

-- Back-fill columns added after initial release
alter table invoice_batches add column if not exists tenant_id  uuid references tenants(id)   on delete set null;
alter table invoice_batches add column if not exists company_id uuid references companies(id) on delete set null;
alter table invoice_batches add column if not exists scan_mode  varchar(20) default 'summary';

-- Ensure scan_mode is never NULL on old rows
update invoice_batches set scan_mode = 'summary' where scan_mode is null;

create index if not exists idx_invoice_batches_tenant_id  on invoice_batches(tenant_id);
create index if not exists idx_invoice_batches_company_id on invoice_batches(company_id);


-- ---------------------------------------------------------------------------
-- INVOICE FILES  (one file record per uploaded file within a batch)
-- ---------------------------------------------------------------------------
create table if not exists invoice_files (
    id                bigserial   primary key,
    batch_id          uuid        not null references invoice_batches(id) on delete cascade,
    tenant_id         uuid        references tenants(id)   on delete set null,
    company_id        uuid        references companies(id) on delete set null,
    original_filename varchar(500) not null,
    stored_filename   varchar(500) not null,
    file_path         text         not null,
    mime_type         varchar(255),
    file_size_bytes   integer,
    status            varchar(50)  not null default 'uploaded',
    page_count        integer,
    error_message     text,
    uploaded_at       timestamptz  not null default now(),
    processed_at      timestamptz
);

-- Back-fill columns added after initial release
alter table invoice_files add column if not exists tenant_id       uuid references tenants(id)   on delete set null;
alter table invoice_files add column if not exists company_id      uuid references companies(id) on delete set null;
alter table invoice_files add column if not exists file_size_bytes integer;

create index if not exists idx_invoice_files_batch_id   on invoice_files(batch_id);
create index if not exists idx_invoice_files_tenant_id  on invoice_files(tenant_id);
create index if not exists idx_invoice_files_company_id on invoice_files(company_id);


-- ---------------------------------------------------------------------------
-- INVOICE ROWS  (one row per extracted invoice / line item)
-- ---------------------------------------------------------------------------
create table if not exists invoice_rows (
    id                       bigserial    primary key,
    batch_id                 uuid         not null references invoice_batches(id) on delete cascade,
    tenant_id                uuid         references tenants(id)       on delete set null,
    company_id               uuid         references companies(id)     on delete set null,
    source_file_id           bigint       references invoice_files(id) on delete set null,
    source_filename          varchar(500),
    page_no                  integer      not null,
    supplier_name            text,
    supplier_posting_account varchar(100),
    nominal_account_code     varchar(100),
    invoice_number           text,
    invoice_date             date,
    description              text,
    line_items_raw           text,
    net_amount               numeric(14,2),
    vat_amount               numeric(14,2),
    total_amount             numeric(14,2),
    currency                 varchar(20),
    tax_code                 varchar(50),
    method_used              varchar(200),
    confidence_score         numeric(5,2),
    validation_status        varchar(100),
    review_required          boolean      not null default false,
    header_raw               text,
    totals_raw               text,
    page_text_raw            text,
    created_at               timestamptz  not null default now()
);

-- Back-fill columns added after initial release
alter table invoice_rows add column if not exists tenant_id               uuid         references tenants(id)       on delete set null;
alter table invoice_rows add column if not exists company_id              uuid         references companies(id)     on delete set null;
alter table invoice_rows add column if not exists supplier_posting_account varchar(100);
alter table invoice_rows add column if not exists nominal_account_code    varchar(100);

-- Widen method_used if it was created as varchar(50) on older installs
alter table invoice_rows alter column method_used type varchar(200);

create index if not exists idx_invoice_rows_batch_id    on invoice_rows(batch_id);
create index if not exists idx_invoice_rows_tenant_id   on invoice_rows(tenant_id);
create index if not exists idx_invoice_rows_company_id  on invoice_rows(company_id);


-- ---------------------------------------------------------------------------
-- SUPPLIER PATTERNS  (keyword fingerprints for auto-matching future invoices)
-- ---------------------------------------------------------------------------
create table if not exists supplier_patterns (
    id          bigserial   primary key,
    tenant_id   uuid        not null references tenants(id)          on delete cascade,
    company_id  uuid        not null references companies(id)        on delete cascade,
    supplier_id bigint      not null references tenant_suppliers(id) on delete cascade,
    keywords    text,
    hit_count   integer     not null default 1,
    last_seen_at timestamptz not null default now(),
    created_at  timestamptz not null default now(),
    constraint uq_supplier_pattern unique (tenant_id, company_id, supplier_id)
);

create index if not exists idx_supplier_patterns_tenant_id   on supplier_patterns(tenant_id);
create index if not exists idx_supplier_patterns_supplier_id on supplier_patterns(supplier_id);


-- ---------------------------------------------------------------------------
-- INVOICE READ HEADERS  (one read snapshot per scanned page)
-- ---------------------------------------------------------------------------
create table if not exists invoice_read_headers (
    id                            bigserial    primary key,
    batch_id                      uuid         not null references invoice_batches(id) on delete cascade,
    tenant_id                     uuid         references tenants(id) on delete set null,
    company_id                    uuid         references companies(id) on delete set null,
    source_file_id                bigint       references invoice_files(id) on delete set null,
    row_id                        bigint       references invoice_rows(id) on delete set null,
    source_filename               varchar(500),
    page_no                       integer      not null,
    provider_name                 varchar(80)  not null,
    extraction_source             varchar(80),
    method_used                   text,
    baseline_mode                 boolean      not null default false,
    document_type                 varchar(80),
    document_confidence           numeric(6,4),
    supplier_name                 text,
    supplier_vat                  varchar(100),
    supplier_address              text,
    supplier_address_recipient    text,
    customer_name                 text,
    customer_vat                  varchar(100),
    customer_address              text,
    customer_address_recipient    text,
    invoice_number                text,
    invoice_date                  varchar(80),
    due_date                      varchar(80),
    order_number                  varchar(120),
    purchase_order                varchar(120),
    description                   text,
    net_amount                    numeric(14,2),
    vat_amount                    numeric(14,2),
    total_amount                  numeric(14,2),
    currency                      varchar(20),
    header_text                   text,
    totals_text                   text,
    page_text                     text,
    raw_provider_fields           json,
    raw_provider_payload          json,
    raw_di_fields                 json,
    raw_di_payload                json,
    "BatchPages"                  integer,
    "DocumentInBatch"             integer,
    "DocType"                     varchar(80),
    "DocumentConfidence"          numeric(6,4),
    "CustomerName"                text,
    "CustomerId"                  varchar(120),
    "PurchaseOrder"               varchar(120),
    "InvoiceId"                   text,
    "InvoiceDate"                 varchar(80),
    "DueDate"                     varchar(80),
    "VendorName"                  text,
    "VendorAddress"               text,
    "VendorAddressRecipient"      text,
    "CustomerAddress"             text,
    "CustomerAddressRecipient"    text,
    "BillingAddress"              text,
    "BillingAddressRecipient"     text,
    "ShippingAddress"             text,
    "ShippingAddressRecipient"    text,
    "SubTotal"                    text,
    "TotalDiscount"               text,
    "TotalTax"                    text,
    "InvoiceTotal"                text,
    "AmountDue"                   text,
    "PreviousUnpaidBalance"       text,
    "RemittanceAddress"           text,
    "RemittanceAddressRecipient"  text,
    "ServiceAddress"              text,
    "ServiceAddressRecipient"     text,
    "ServiceStartDate"            varchar(80),
    "ServiceEndDate"              varchar(80),
    "VendorTaxId"                 varchar(120),
    "CustomerTaxId"               varchar(120),
    "PaymentTerm"                 text,
    "KVKNumber"                   varchar(120),
    "CurrencyCode"                varchar(20),
    "VendorPhoneNumber"           varchar(120),
    "CustomerPhoneNumber"         varchar(120),
    "BillingPhoneNumber"          varchar(120),
    "VendorEmail"                 varchar(255),
    "VendorFaxNumber"             varchar(120),
    "ReferenceNumber"             varchar(120),
    "PaymentDetails"              json,
    "TaxDetails"                  json,
    "PaidInFourInstallements"     json,
    created_at                    timestamptz  not null default now()
);

create index if not exists ix_invoice_read_headers_batch_page on invoice_read_headers(batch_id, page_no);
create index if not exists ix_invoice_read_headers_row        on invoice_read_headers(row_id);
create index if not exists ix_invoice_read_headers_provider   on invoice_read_headers(provider_name);


-- ---------------------------------------------------------------------------
-- INVOICE READ DETAILS  (structured line items for each read snapshot)
-- ---------------------------------------------------------------------------
create table if not exists invoice_read_details (
    id           bigserial   primary key,
    header_id    bigint      not null references invoice_read_headers(id) on delete cascade,
    line_no      integer,
    description  text,
    quantity     numeric(14,4),
    unit_price   numeric(14,4),
    net_amount   numeric(14,2),
    tax_amount   numeric(14,2),
    "Amount"     text,
    "Date"       varchar(80),
    "Description" text,
    "ProductCode" varchar(120),
    "Quantity"   varchar(80),
    "Tax"        text,
    "TaxRate"    varchar(80),
    "Unit"       varchar(80),
    "UnitPrice"  text,
    raw_detail   json,
    created_at   timestamptz not null default now()
);

create index if not exists ix_invoice_read_details_header on invoice_read_details(header_id);


-- ---------------------------------------------------------------------------
-- INVOICE FIELD CANDIDATES  (field evidence for resolver/review/learning)
-- ---------------------------------------------------------------------------
create table if not exists invoice_field_candidates (
    id               bigserial   primary key,
    tenant_id        uuid        not null references tenants(id) on delete cascade,
    company_id       uuid        references companies(id) on delete set null,
    batch_id         uuid        not null references invoice_batches(id) on delete cascade,
    row_id           bigint      not null references invoice_rows(id) on delete cascade,
    source_file_id   bigint      references invoice_files(id) on delete set null,
    field_name       varchar(80) not null,
    candidate_value  text,
    normalised_value text,
    source_type      varchar(80) not null,
    source_id        text,
    confidence       numeric(6,4),
    evidence         text,
    reason           text,
    selected         boolean     not null default false,
    applied          boolean     not null default false,
    rejected_reason  text,
    conflict         boolean     not null default false,
    user_accepted    boolean     not null default false,
    user_corrected   boolean     not null default false,
    final_value      text,
    finalised_at     timestamptz,
    finalised_by     uuid references users(id),
    outcome_source   varchar(40),
    created_at       timestamptz not null default now()
);

create index if not exists ix_field_candidates_tenant_company on invoice_field_candidates(tenant_id, company_id);
create index if not exists ix_field_candidates_batch_row     on invoice_field_candidates(batch_id, row_id);
create index if not exists ix_field_candidates_field_name    on invoice_field_candidates(field_name);
create index if not exists ix_field_candidates_source_type   on invoice_field_candidates(source_type);
create index if not exists ix_field_candidates_selected      on invoice_field_candidates(selected);
create index if not exists ix_field_candidates_created_at    on invoice_field_candidates(created_at);


-- =============================================================================
-- End of schema
-- =============================================================================
