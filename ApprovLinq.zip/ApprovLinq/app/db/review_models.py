"""Review/correction layer models. Imported by app.db.models via __init__ side effect.

Kept in a separate file to avoid editing the existing models.py. The InvoiceBatch
additive columns are attached dynamically below using SQLAlchemy's add_to_class
pattern via direct setattr on the existing mapped class — safe because columns
are nullable / defaulted.
"""
from __future__ import annotations
import uuid
from datetime import datetime, date
from sqlalchemy import (
    Boolean, DateTime, Date, ForeignKey, Integer, BigInteger, Numeric, String, Text, LargeBinary, Index,
)
from sqlalchemy.orm import Mapped, mapped_column
from app.db.models import Base, InvoiceBatch  # noqa: F401


def _utcnow() -> datetime:
    return datetime.utcnow()


CORRECTABLE_FIELDS: tuple[str, ...] = (
    "supplier_name", "supplier_posting_account", "nominal_account_code",
    "invoice_number", "invoice_date", "description",
    "net_amount", "vat_amount", "total_amount", "currency", "tax_code",
)


class InvoiceRowCorrection(Base):
    __tablename__ = "invoice_row_corrections"
    row_id: Mapped[int] = mapped_column(ForeignKey("invoice_rows.id", ondelete="CASCADE"), primary_key=True)
    batch_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("invoice_batches.id", ondelete="CASCADE"), nullable=False)
    supplier_name: Mapped[str | None] = mapped_column(Text)
    supplier_posting_account: Mapped[str | None] = mapped_column(String(100))
    nominal_account_code: Mapped[str | None] = mapped_column(String(100))
    invoice_number: Mapped[str | None] = mapped_column(Text)
    invoice_date: Mapped[date | None] = mapped_column(Date)
    description: Mapped[str | None] = mapped_column(Text)
    net_amount: Mapped[float | None] = mapped_column(Numeric(14, 2))
    vat_amount: Mapped[float | None] = mapped_column(Numeric(14, 2))
    total_amount: Mapped[float | None] = mapped_column(Numeric(14, 2))
    currency: Mapped[str | None] = mapped_column(String(20))
    tax_code: Mapped[str | None] = mapped_column(String(50))
    reviewed_fields: Mapped[str | None] = mapped_column(Text)
    row_reviewed: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, nullable=False)
    updated_by: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id"), nullable=True)


class InvoiceRowFieldAudit(Base):
    __tablename__ = "invoice_row_field_audits"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    batch_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("invoice_batches.id", ondelete="CASCADE"), nullable=False)
    row_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    field_name: Mapped[str] = mapped_column(String(80), nullable=False)
    old_value: Mapped[str | None] = mapped_column(Text)
    new_value: Mapped[str | None] = mapped_column(Text)
    action: Mapped[str] = mapped_column(String(40), nullable=False)
    note: Mapped[str | None] = mapped_column(Text)
    rule_created: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    force_added: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    user_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    username: Mapped[str | None] = mapped_column(String(255))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, nullable=False)


class InvoiceFieldCandidate(Base):
    """Persistent field-candidate evidence for future ML/ranking.

    Phase 8A only creates the table.  Candidates are not written yet; later
    phases will persist arbitration candidates and user outcome labels.
    """
    __tablename__ = "invoice_field_candidates"
    __table_args__ = (
        Index("ix_field_candidates_tenant_company", "tenant_id", "company_id"),
        Index("ix_field_candidates_batch_row", "batch_id", "row_id"),
        Index("ix_field_candidates_field_name", "field_name"),
        Index("ix_field_candidates_source_type", "source_type"),
        Index("ix_field_candidates_selected", "selected"),
        Index("ix_field_candidates_created_at", "created_at"),
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    tenant_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False)
    company_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("companies.id", ondelete="SET NULL"), nullable=True)
    batch_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("invoice_batches.id", ondelete="CASCADE"), nullable=False)
    row_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("invoice_rows.id", ondelete="CASCADE"), nullable=False)
    source_file_id: Mapped[int | None] = mapped_column(BigInteger, ForeignKey("invoice_files.id", ondelete="SET NULL"), nullable=True)
    field_name: Mapped[str] = mapped_column(String(80), nullable=False)
    candidate_value: Mapped[str | None] = mapped_column(Text, nullable=True)
    normalised_value: Mapped[str | None] = mapped_column(Text, nullable=True)
    source_type: Mapped[str] = mapped_column(String(80), nullable=False)
    source_id: Mapped[str | None] = mapped_column(Text, nullable=True)
    confidence: Mapped[float | None] = mapped_column(Numeric(6, 4), nullable=True)
    evidence: Mapped[str | None] = mapped_column(Text, nullable=True)
    reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    selected: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    applied: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    rejected_reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    conflict: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    # Phase 8D outcome labels: populated only after explicit review/acceptance/export.
    user_accepted: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    user_corrected: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    final_value: Mapped[str | None] = mapped_column(Text, nullable=True)
    finalised_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finalised_by: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    outcome_source: Mapped[str | None] = mapped_column(String(40), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, nullable=False)


class CorrectionRule(Base):
    __tablename__ = "correction_rules"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    tenant_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False)
    company_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("companies.id", ondelete="CASCADE"), nullable=True)
    rule_type: Mapped[str] = mapped_column(String(40), nullable=False)
    field_name: Mapped[str] = mapped_column(String(80), nullable=False)
    source_pattern: Mapped[str] = mapped_column(Text, nullable=False)
    target_value: Mapped[str] = mapped_column(Text, nullable=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_by: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, nullable=False)
    disabled_by: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    disabled_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    origin_batch_id: Mapped[uuid.UUID | None] = mapped_column(nullable=True)
    origin_row_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    # Platform-admin global rules apply in the background for every tenant.
    # tenant_id remains populated for origin/audit compatibility.
    is_global: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)


class RemapHint(Base):
    __tablename__ = "remap_hints"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    tenant_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False)
    company_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("companies.id", ondelete="CASCADE"), nullable=True)
    supplier_id: Mapped[int | None] = mapped_column(BigInteger, ForeignKey("tenant_suppliers.id", ondelete="CASCADE"), nullable=True)
    supplier_name_snapshot: Mapped[str | None] = mapped_column(Text)
    field_name: Mapped[str] = mapped_column(String(80), nullable=False)
    page_no: Mapped[int | None] = mapped_column(Integer)  # reference page only; not identity
    x: Mapped[float | None] = mapped_column(Numeric(8, 4))
    y: Mapped[float | None] = mapped_column(Numeric(8, 4))
    w: Mapped[float | None] = mapped_column(Numeric(8, 4))
    h: Mapped[float | None] = mapped_column(Numeric(8, 4))
    source_batch_id: Mapped[uuid.UUID | None] = mapped_column(nullable=True)
    source_file_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    source_row_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_by: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, nullable=False)

    # Governance / lifecycle.  Saved regions are supplier-field instructions,
    # not throwaway page coordinates.  Page is only a reference hint.
    is_primary: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    archived: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    archived_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    archived_by: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    deleted_by: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    superseded_by_hint_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)

    # Usage telemetry used by governance UI and future ML/candidate ranking.
    last_used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_used_batch_id: Mapped[uuid.UUID | None] = mapped_column(nullable=True)
    last_used_row_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    last_used_page_no: Mapped[int | None] = mapped_column(Integer, nullable=True)
    last_read_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    last_result: Mapped[str | None] = mapped_column(Text, nullable=True)
    success_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    failure_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    conflict_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    apply_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)


class BatchExportEvent(Base):
    __tablename__ = "batch_export_events"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    batch_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("invoice_batches.id", ondelete="CASCADE"), nullable=False)
    export_version: Mapped[int] = mapped_column(Integer, nullable=False)
    template_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    exported_by: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    exported_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, nullable=False)
    file_path: Mapped[str | None] = mapped_column(Text)
    # Durable copy of generated exports. The file_path remains a local cache path,
    # but the bytes survive Koyeb redeploys when stored in Postgres.
    file_bytes: Mapped[bytes | None] = mapped_column(LargeBinary, nullable=True)
    storage_backend: Mapped[str] = mapped_column(String(30), default="database+local", nullable=False)
    row_count: Mapped[int | None] = mapped_column(Integer)


# Attach additive columns to InvoiceBatch dynamically (declarative add_to_class).
# These are nullable / defaulted, so adding them post-mapping is safe.
def _ensure_batch_columns() -> None:
    cols = {
        "approved_at":  mapped_column(DateTime(timezone=True), nullable=True),
        "approved_by":  mapped_column(ForeignKey("users.id"), nullable=True),
        "exported_at":  mapped_column(DateTime(timezone=True), nullable=True),
        "exported_by":  mapped_column(ForeignKey("users.id"), nullable=True),
        "reopened_at":  mapped_column(DateTime(timezone=True), nullable=True),
        "reopened_by":  mapped_column(ForeignKey("users.id"), nullable=True),
        "current_export_version": mapped_column(Integer, nullable=False, default=0, server_default="0"),
    }
    for name, col in cols.items():
        if not hasattr(InvoiceBatch, name):
            try:
                InvoiceBatch.__table__.append_column(col.column)  # type: ignore[attr-defined]
            except Exception:
                pass


_ensure_batch_columns()
