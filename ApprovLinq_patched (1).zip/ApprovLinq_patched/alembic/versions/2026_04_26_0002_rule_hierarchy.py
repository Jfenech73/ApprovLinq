"""Add rule hierarchy: scope, priority, visibility, association table.

Revision ID: 0002_rule_hierarchy
Revises: 2026_04_11_0001_review_layer
Create Date: 2026-04-26
"""
from __future__ import annotations
from alembic import op
import sqlalchemy as sa
try:
    from sqlalchemy.dialects import postgresql
    _UUID = postgresql.UUID(as_uuid=True)
except Exception:
    _UUID = sa.Text()

revision = "0002_rule_hierarchy"
down_revision = "2026_04_11_0001_review_layer"
branch_labels = None
depends_on = None


def upgrade() -> None:
    conn = op.get_bind()
    insp = sa.inspect(conn)
    existing_cols = {c["name"] for c in insp.get_columns("correction_rules")}

    # ── Additive columns on correction_rules ──────────────────────────────────
    # All nullable or server-defaulted so existing rows are unaffected.
    if "scope" not in existing_cols:
        op.add_column("correction_rules",
            sa.Column("scope", sa.String(40), nullable=False,
                      server_default="company"))

    if "priority" not in existing_cols:
        op.add_column("correction_rules",
            sa.Column("priority", sa.Integer(), nullable=False,
                      server_default="0"))

    if "is_hidden_global" not in existing_cols:
        op.add_column("correction_rules",
            sa.Column("is_hidden_global", sa.Boolean(), nullable=False,
                      server_default=sa.false()))

    if "created_by_role" not in existing_cols:
        op.add_column("correction_rules",
            sa.Column("created_by_role", sa.String(40), nullable=True))

    if "hit_count" not in existing_cols:
        op.add_column("correction_rules",
            sa.Column("hit_count", sa.Integer(), nullable=False,
                      server_default="0"))

    if "success_count" not in existing_cols:
        op.add_column("correction_rules",
            sa.Column("success_count", sa.Integer(), nullable=False,
                      server_default="0"))

    if "last_used_at" not in existing_cols:
        op.add_column("correction_rules",
            sa.Column("last_used_at", sa.DateTime(timezone=True), nullable=True))

    # tenant_id made nullable to support admin_global_hidden rules
    # (safe: existing rows all have a tenant_id; new global rules will have NULL)
    try:
        op.alter_column("correction_rules", "tenant_id", nullable=True)
    except Exception:
        pass  # already nullable or dialect difference

    # Backfill scope for existing rows: company if company_id set, else tenant_all_companies
    op.execute("""
        UPDATE correction_rules
        SET scope = CASE
            WHEN company_id IS NOT NULL THEN 'company'
            ELSE 'tenant_all_companies'
        END
        WHERE scope = 'company'
          AND is_hidden_global = false
    """)

    # ── New index for scope-aware queries ─────────────────────────────────────
    existing_indexes = {i["name"] for i in insp.get_indexes("correction_rules")}
    if "ix_rules_scope_lookup" not in existing_indexes:
        op.create_index(
            "ix_rules_scope_lookup",
            "correction_rules",
            ["tenant_id", "scope", "field_name", "active"],
        )

    # ── correction_rule_companies association table ───────────────────────────
    if "correction_rule_companies" not in insp.get_table_names():
        op.create_table(
            "correction_rule_companies",
            sa.Column("rule_id", sa.BigInteger(),
                      sa.ForeignKey("correction_rules.id", ondelete="CASCADE"),
                      primary_key=True, nullable=False),
            sa.Column("company_id", _UUID,
                      sa.ForeignKey("companies.id", ondelete="CASCADE"),
                      primary_key=True, nullable=False),
        )
        op.create_index(
            "ix_rule_companies_company",
            "correction_rule_companies",
            ["company_id"],
        )


def downgrade() -> None:
    # Drop association table first
    op.drop_table("correction_rule_companies")
    # Drop added columns (order matters for some DBs)
    for col in ("last_used_at", "success_count", "hit_count",
                "created_by_role", "is_hidden_global", "priority", "scope"):
        try:
            op.drop_column("correction_rules", col)
        except Exception:
            pass
    try:
        op.drop_index("ix_rules_scope_lookup", table_name="correction_rules")
    except Exception:
        pass
