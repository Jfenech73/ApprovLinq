"""Rule engine — scope-aware rule loading, precedence resolution, and audit.

This module is the single authoritative place for:
  - Loading applicable rules for a given tenant/company context
  - Applying deterministic precedence across scopes
  - Enforcing visibility (admin_global_hidden rules are never returned to tenants)
  - Recording rule hits for analytics

Precedence order (most specific wins):
  1. company                    — applies to one specific company
  2. tenant_selected_companies  — applies to selected companies in one tenant
  3. tenant_all_companies       — applies to all companies in one tenant
  4. admin_global_hidden        — platform-wide background rules

Within a scope, tie-break by: priority DESC, id DESC (most recent).
"""
from __future__ import annotations

import logging
from datetime import datetime
from typing import Sequence
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db.review_models import (
    CorrectionRule,
    CorrectionRuleCompany,
    RULE_SCOPE_COMPANY,
    RULE_SCOPE_TENANT_SELECTED,
    RULE_SCOPE_TENANT_ALL,
    RULE_SCOPE_ADMIN_GLOBAL_HIDDEN,
    RULE_SCOPE_PRECEDENCE,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def load_applicable_rules(
    db: Session,
    *,
    tenant_id: UUID | None,
    company_id: UUID | None,
    include_global: bool = True,
) -> list[CorrectionRule]:
    """Return all active rules that apply to this tenant/company context.

    Rules are returned in deterministic precedence order (most specific first).
    admin_global_hidden rules are included at the end when include_global=True.
    This function never leaks rules from other tenants.
    """
    candidates: list[CorrectionRule] = []

    # ── 1. Company-scoped rules ───────────────────────────────────────────────
    if tenant_id and company_id:
        rows = db.execute(
            select(CorrectionRule).where(
                CorrectionRule.tenant_id == tenant_id,
                CorrectionRule.company_id == company_id,
                CorrectionRule.scope == RULE_SCOPE_COMPANY,
                CorrectionRule.active.is_(True),
            )
        ).scalars().all()
        candidates.extend(rows)

    # ── 2. Tenant selected-companies rules ────────────────────────────────────
    if tenant_id and company_id:
        # A rule is applicable if this company is in the rule's company list
        sel_rule_ids = db.execute(
            select(CorrectionRuleCompany.rule_id).where(
                CorrectionRuleCompany.company_id == company_id,
            )
        ).scalars().all()
        if sel_rule_ids:
            rows = db.execute(
                select(CorrectionRule).where(
                    CorrectionRule.id.in_(sel_rule_ids),
                    CorrectionRule.tenant_id == tenant_id,
                    CorrectionRule.scope == RULE_SCOPE_TENANT_SELECTED,
                    CorrectionRule.active.is_(True),
                )
            ).scalars().all()
            candidates.extend(rows)

    # ── 3. Tenant all-companies rules ─────────────────────────────────────────
    if tenant_id:
        rows = db.execute(
            select(CorrectionRule).where(
                CorrectionRule.tenant_id == tenant_id,
                CorrectionRule.scope == RULE_SCOPE_TENANT_ALL,
                CorrectionRule.active.is_(True),
            )
        ).scalars().all()
        candidates.extend(rows)

    # ── 4. Admin global hidden rules ──────────────────────────────────────────
    if include_global:
        rows = db.execute(
            select(CorrectionRule).where(
                CorrectionRule.scope == RULE_SCOPE_ADMIN_GLOBAL_HIDDEN,
                CorrectionRule.is_hidden_global.is_(True),
                CorrectionRule.active.is_(True),
            )
        ).scalars().all()
        candidates.extend(rows)

    # Deduplicate (a rule shouldn't appear twice, but guard anyway)
    seen: set[int] = set()
    deduped: list[CorrectionRule] = []
    for r in candidates:
        if r.id not in seen:
            seen.add(r.id)
            deduped.append(r)

    # Sort: scope precedence ASC (1=most specific), then priority DESC, then id DESC
    deduped.sort(key=lambda r: (
        RULE_SCOPE_PRECEDENCE.get(r.scope, 99),
        -(r.priority or 0),
        -r.id,
    ))
    return deduped


def record_rule_hit(db: Session, rule: CorrectionRule, *, success: bool = True) -> None:
    """Increment hit/success counters and update last_used_at. Non-fatal."""
    try:
        rule.hit_count = (rule.hit_count or 0) + 1
        if success:
            rule.success_count = (rule.success_count or 0) + 1
        rule.last_used_at = datetime.utcnow()
    except Exception as exc:
        logger.debug("record_rule_hit failed (non-fatal): %s", exc)


def rules_visible_to_tenant(
    db: Session,
    *,
    tenant_id: UUID,
    company_id: UUID | None = None,
    active_only: bool = False,
) -> list[CorrectionRule]:
    """Return rules a tenant user is allowed to see.

    Excludes admin_global_hidden rules entirely — tenants must never see those.
    """
    q = select(CorrectionRule).where(
        CorrectionRule.tenant_id == tenant_id,
        CorrectionRule.scope != RULE_SCOPE_ADMIN_GLOBAL_HIDDEN,
        CorrectionRule.is_hidden_global.is_(False),
    )
    if company_id:
        # Show: company rules for this company + tenant-wide rules
        q = q.where(
            (CorrectionRule.company_id == company_id)
            | (CorrectionRule.company_id.is_(None))
        )
    if active_only:
        q = q.where(CorrectionRule.active.is_(True))
    return db.execute(q.order_by(
        CorrectionRule.scope,
        CorrectionRule.priority.desc(),
        CorrectionRule.created_at.desc(),
    )).scalars().all()


def rule_scope_label(scope: str) -> str:
    """Human-readable scope label safe for tenant-facing display."""
    return {
        RULE_SCOPE_COMPANY:             "This company",
        RULE_SCOPE_TENANT_SELECTED:     "Selected companies",
        RULE_SCOPE_TENANT_ALL:          "All companies (tenant)",
        RULE_SCOPE_ADMIN_GLOBAL_HIDDEN: "System-managed",
    }.get(scope, scope)


def rule_audit_source(rule: CorrectionRule) -> str:
    """Safe audit source label — never leaks global rule origin to tenants."""
    if rule.scope == RULE_SCOPE_ADMIN_GLOBAL_HIDDEN:
        return "system"
    return "rule"
