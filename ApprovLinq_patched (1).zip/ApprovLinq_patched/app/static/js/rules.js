/* rules.js — Rules management page with scope/hierarchy support */
"use strict";

async function api(path, options = {}) {
  return apiFetch(path, options);
}

// ── State ─────────────────────────────────────────────────────────────────────
let _allRules   = [];
let _editingId  = null;
let _companies  = [];
let _isAdmin    = false;

// ── Helpers ───────────────────────────────────────────────────────────────────
function setMsg(el, text, kind) {
  if (!el) return;
  el.textContent = text || "";
  el.className   = "message" + (kind ? " " + kind : "");
}

function fmtDate(iso) {
  if (!iso) return "—";
  try { return new Date(iso).toLocaleDateString(undefined, { day: "2-digit", month: "short", year: "numeric" }); }
  catch { return iso.slice(0, 10); }
}

function fieldLabel(fn) {
  return ({
    supplier_name: "Supplier name", nominal_account_code: "Nominal code",
    supplier_posting_account: "Posting account", invoice_number: "Invoice number",
    invoice_date: "Invoice date", description: "Description",
    tax_code: "Tax code", currency: "Currency",
  })[fn] || (fn || "—");
}

function typeLabel(rt) {
  return ({
    supplier_alias: "Supplier alias", nominal_remap: "Nominal remap",
    text_correction: "Text correction", remap_field_value: "Remap field",
  })[rt] || (rt || "");
}

function scopeLabel(s) {
  return ({
    company: "This company",
    tenant_selected_companies: "Selected companies",
    tenant_all_companies: "All companies",
    admin_global_hidden: "System (hidden)",
  })[s] || (s || "—");
}

function scopePill(s) {
  const label = scopeLabel(s);
  const color = {
    company: "var(--ap-primary,#1e3a5f)",
    tenant_selected_companies: "#6366f1",
    tenant_all_companies: "#0891b2",
    admin_global_hidden: "#9333ea",
  }[s] || "var(--ap-text-muted)";
  return `<span style="font-size:11px;padding:1px 6px;border-radius:99px;border:1px solid ${color};color:${color}">${escHtml(label)}</span>`;
}

function escHtml(s) {
  return String(s || "").replace(/&/g,"&amp;").replace(/</g,"&lt;")
                        .replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}

// ── Data loading ──────────────────────────────────────────────────────────────
async function loadCompanies() {
  try {
    const list = await api("/tenant/companies");
    _companies = (list || []).map(c => ({ id: c.id, name: c.company_name || c.company_code }));

    // Populate filter dropdown
    const sel = document.getElementById("companyFilter");
    _companies.forEach(c => {
      const o = document.createElement("option");
      o.value = c.id; o.textContent = c.name; sel.appendChild(o);
    });

    // Populate create-modal company selectors
    const createCo = document.getElementById("createCompany");
    const createCos = document.getElementById("createCompanies");
    _companies.forEach(c => {
      [createCo, createCos].forEach(el => {
        const o = document.createElement("option");
        o.value = c.id; o.textContent = c.name; el.appendChild(o);
      });
    });
  } catch (_) {}
}

async function detectAdminRole() {
  try {
    const me = await api("/auth/me");
    _isAdmin = (me && me.role === "admin");
    if (_isAdmin) {
      // Add admin_global_hidden option to scope filters/selectors
      const scopeFilter = document.getElementById("scopeFilter");
      const opt = document.createElement("option");
      opt.value = "admin_global_hidden"; opt.textContent = "System / hidden (admin)";
      scopeFilter.appendChild(opt);

      const createScope = document.getElementById("createScope");
      const opt2 = document.createElement("option");
      opt2.value = "admin_global_hidden"; opt2.textContent = "Platform-wide hidden (admin only)";
      createScope.appendChild(opt2);
    }
  } catch (_) {}
}

async function loadRules() {
  setMsg(document.getElementById("pageMessage"), "");
  document.getElementById("rulesTableBody").innerHTML =
    '<tr><td colspan="9" class="muted" style="text-align:center;padding:24px">Loading…</td></tr>';

  const cid   = document.getElementById("companyFilter").value;
  const scope = document.getElementById("scopeFilter").value;

  // Admin uses /admin/rules for full view including global hidden
  const base = _isAdmin ? "/review/admin/rules" : "/review/rules";
  const params = new URLSearchParams();
  if (cid)   params.set("company_id", cid);
  if (scope) params.set("scope", scope);
  const url = base + (params.toString() ? "?" + params.toString() : "");

  try {
    _allRules = await api(url);
    renderTable();
  } catch (e) {
    setMsg(document.getElementById("pageMessage"),
      "Failed to load rules: " + (e.message || e), "error");
    document.getElementById("rulesTableBody").innerHTML =
      '<tr><td colspan="9" class="muted" style="text-align:center">Error loading rules.</td></tr>';
  }
}

// ── Render ────────────────────────────────────────────────────────────────────
function renderTable() {
  const sf  = document.getElementById("statusFilter").value;
  const q   = document.getElementById("searchInput").value.trim().toLowerCase();

  const rows = _allRules.filter(r => {
    if (sf === "active"   && !r.active) return false;
    if (sf === "disabled" &&  r.active) return false;
    if (q && !((r.source_pattern + " " + r.target_value + " " + (r.field_name||"") + " " + (r.scope||"")).toLowerCase().includes(q))) return false;
    return true;
  });

  document.getElementById("ruleCount").textContent = rows.length + " rule" + (rows.length !== 1 ? "s" : "");

  if (!rows.length) {
    document.getElementById("rulesTableBody").innerHTML =
      '<tr><td colspan="9" class="muted" style="text-align:center;padding:24px">No rules match the current filters.</td></tr>';
    return;
  }

  const coName = id => (_companies.find(c => c.id === id) || {}).name || (id ? "Company" : "—");

  document.getElementById("rulesTableBody").innerHTML = rows.map(r => {
    const pill  = r.active
      ? '<span class="pill ok" style="font-size:11px">active</span>'
      : '<span class="pill"    style="font-size:11px;background:var(--ap-bg-sub)">disabled</span>';
    const tog   = r.active
      ? `<button class="btn btn-sm" data-action="disable" data-id="${r.id}" style="color:var(--ap-warn-fg)">Disable</button>`
      : `<button class="btn btn-sm" data-action="enable"  data-id="${r.id}" style="color:var(--ap-ok-fg)">Enable</button>`;
    const promoteBtn = (_isAdmin && r.scope !== "admin_global_hidden")
      ? `<button class="btn btn-sm" data-action="promote" data-id="${r.id}" title="Promote to platform-wide hidden rule" style="color:#9333ea">Promote</button>`
      : "";
    // Don't show edit/delete for hidden global rules to non-admins (shouldn't appear anyway)
    const editBtn   = `<button class="btn btn-sm" data-action="edit"   data-id="${r.id}">Edit</button>`;
    const deleteBtn = `<button class="btn btn-sm" data-action="delete" data-id="${r.id}" style="color:var(--ap-err-fg);border-color:var(--ap-err-fg)">Delete</button>`;
    const hitsText  = r.hit_count > 0
      ? `<span class="muted" style="font-size:11px">${r.hit_count}${r.success_count ? "/" + r.success_count : ""}</span>`
      : '<span class="muted" style="font-size:11px">—</span>';

    return `<tr data-id="${r.id}" class="${r.active?"":"muted"}">
      <td>
        <strong style="font-size:var(--ap-fs-13)">${escHtml(fieldLabel(r.field_name))}</strong>
        ${r.rule_type ? `<br><span class="muted" style="font-size:11px">${escHtml(typeLabel(r.rule_type))}</span>` : ""}
      </td>
      <td><code style="font-size:var(--ap-fs-12)">${escHtml(r.source_pattern)}</code></td>
      <td><strong>${escHtml(r.target_value)}</strong></td>
      <td>${scopePill(r.scope)}</td>
      <td><span class="muted" style="font-size:12px">${r.priority > 0 ? r.priority : "—"}</span></td>
      <td>${hitsText}</td>
      <td>${pill}</td>
      <td><span class="muted" style="font-size:12px">${fmtDate(r.created_at)}</span></td>
      <td style="text-align:right;white-space:nowrap">
        ${editBtn}${tog}${promoteBtn}${deleteBtn}
      </td>
    </tr>`;
  }).join("");
}

// ── Table actions ─────────────────────────────────────────────────────────────
document.getElementById("rulesTable").addEventListener("click", async e => {
  const btn    = e.target.closest("[data-action]");
  if (!btn) return;
  const id     = parseInt(btn.dataset.id, 10);
  const action = btn.dataset.action;

  if (action === "edit") { openEditModal(id); return; }

  if (action === "promote") {
    const rule = _allRules.find(r => r.id === id);
    if (!confirm(`Promote rule "${rule.source_pattern}" → "${rule.target_value}" to a platform-wide hidden system rule?\n\nThis will remove it from the tenant's view and apply it in the background across all tenants.`)) return;
    try {
      const updated = await api(`/review/admin/rules/${id}/promote`, { method: "POST" });
      // Remove from tenant-visible list
      _allRules = _allRules.filter(r => r.id !== id);
      if (_isAdmin) {
        // Admin sees it; update the entry
        _allRules.push(updated);
      }
      renderTable();
      setMsg(document.getElementById("pageMessage"), "Rule promoted to system-managed.", "success");
    } catch (err) {
      setMsg(document.getElementById("pageMessage"), "Promote failed: " + (err.message||err), "error");
    }
    return;
  }

  if (action === "delete") {
    const rule = _allRules.find(r => r.id === id);
    if (!confirm(`Delete rule:\n  "${rule.source_pattern}"  →  "${rule.target_value}"\n\nThis cannot be undone.`)) return;
    try {
      const endpoint = _isAdmin ? `/review/admin/rules/${id}` : `/review/rules/${id}`;
      await api(endpoint, { method: "DELETE" });
      _allRules = _allRules.filter(r => r.id !== id);
      renderTable();
      setMsg(document.getElementById("pageMessage"), "Rule deleted.", "success");
    } catch (err) {
      setMsg(document.getElementById("pageMessage"), "Delete failed: " + (err.message||err), "error");
    }
    return;
  }

  if (action === "enable" || action === "disable") {
    try {
      const updated = await api(`/review/rules/${id}/${action}`, { method: "POST" });
      const idx = _allRules.findIndex(r => r.id === id);
      if (idx >= 0) _allRules[idx] = updated;
      renderTable();
      setMsg(document.getElementById("pageMessage"), `Rule ${action}d.`, "success");
    } catch (err) {
      setMsg(document.getElementById("pageMessage"), `Failed to ${action}: ` + (err.message||err), "error");
    }
  }
});

// ── Edit modal ────────────────────────────────────────────────────────────────
function openEditModal(id) {
  const rule = _allRules.find(r => r.id === id);
  if (!rule) return;
  _editingId = id;
  document.getElementById("editSource").value   = rule.source_pattern || "";
  document.getElementById("editTarget").value   = rule.target_value   || "";
  document.getElementById("editPriority").value = rule.priority || 0;
  document.getElementById("editField").textContent =
    fieldLabel(rule.field_name) + (rule.rule_type ? " · " + typeLabel(rule.rule_type) : "") +
    "  —  " + scopeLabel(rule.scope);
  setMsg(document.getElementById("editMessage"), "");
  document.getElementById("editModal").style.display = "flex";
  document.getElementById("editSource").focus();
}

function closeEditModal() {
  document.getElementById("editModal").style.display = "none";
  _editingId = null;
}

document.getElementById("editCancelBtn").addEventListener("click", closeEditModal);
document.getElementById("editModal").addEventListener("click", e => {
  if (e.target === document.getElementById("editModal")) closeEditModal();
});

document.getElementById("editSaveBtn").addEventListener("click", async () => {
  if (!_editingId) return;
  const src = document.getElementById("editSource").value.trim();
  const tgt = document.getElementById("editTarget").value.trim();
  const pri = parseInt(document.getElementById("editPriority").value || "0", 10);
  setMsg(document.getElementById("editMessage"), "");
  if (!src) { setMsg(document.getElementById("editMessage"), "Source pattern cannot be blank.", "error"); return; }
  if (!tgt) { setMsg(document.getElementById("editMessage"), "Target value cannot be blank.",   "error"); return; }
  if (src.toLowerCase() === tgt.toLowerCase()) {
    setMsg(document.getElementById("editMessage"), "Source and target are identical — no effect.", "error"); return;
  }
  const btn = document.getElementById("editSaveBtn");
  btn.disabled = true;
  try {
    const updated = await api(`/review/rules/${_editingId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ source_pattern: src, target_value: tgt, priority: pri }),
    });
    const idx = _allRules.findIndex(r => r.id === _editingId);
    if (idx >= 0) _allRules[idx] = updated;
    closeEditModal();
    renderTable();
    setMsg(document.getElementById("pageMessage"), "Rule updated.", "success");
  } catch (err) {
    setMsg(document.getElementById("editMessage"), "Save failed: " + (err.message || "unknown error"), "error");
  } finally { btn.disabled = false; }
});

// ── Create modal ──────────────────────────────────────────────────────────────
function openCreateModal() {
  document.getElementById("createSource").value   = "";
  document.getElementById("createTarget").value   = "";
  document.getElementById("createPriority").value = "0";
  document.getElementById("createScope").value    = "company";
  updateCreateScopeUI();
  setMsg(document.getElementById("createMessage"), "");
  document.getElementById("createModal").style.display = "flex";
  document.getElementById("createSource").focus();
}

function closeCreateModal() {
  document.getElementById("createModal").style.display = "none";
}

function updateCreateScopeUI() {
  const scope = document.getElementById("createScope").value;
  document.getElementById("createCompanyRow").style.display =
    scope === "company" ? "" : "none";
  document.getElementById("createCompaniesRow").style.display =
    scope === "tenant_selected_companies" ? "" : "none";
}

document.getElementById("createRuleBtn").addEventListener("click", openCreateModal);
document.getElementById("createCancelBtn").addEventListener("click", closeCreateModal);
document.getElementById("createModal").addEventListener("click", e => {
  if (e.target === document.getElementById("createModal")) closeCreateModal();
});
document.getElementById("createScope").addEventListener("change", updateCreateScopeUI);

document.getElementById("createSaveBtn").addEventListener("click", async () => {
  const src   = document.getElementById("createSource").value.trim();
  const tgt   = document.getElementById("createTarget").value.trim();
  const scope = document.getElementById("createScope").value;
  const pri   = parseInt(document.getElementById("createPriority").value || "0", 10);
  const field = document.getElementById("createField").value;
  const type  = document.getElementById("createType").value;

  setMsg(document.getElementById("createMessage"), "");
  if (!src) { setMsg(document.getElementById("createMessage"), "Source pattern cannot be blank.", "error"); return; }
  if (!tgt) { setMsg(document.getElementById("createMessage"), "Target value cannot be blank.",   "error"); return; }
  if (src.toLowerCase() === tgt.toLowerCase()) {
    setMsg(document.getElementById("createMessage"), "Source and target are identical — no effect.", "error"); return;
  }

  // Collect company selections
  let companyId   = null;
  let companyIds  = null;
  if (scope === "company") {
    companyId = document.getElementById("createCompany").value || null;
  } else if (scope === "tenant_selected_companies") {
    companyIds = Array.from(document.getElementById("createCompanies").selectedOptions).map(o => o.value);
    if (!companyIds.length) {
      setMsg(document.getElementById("createMessage"), "Select at least one company.", "error"); return;
    }
  }

  const btn = document.getElementById("createSaveBtn");
  btn.disabled = true;
  try {
    const created = await api("/review/rules", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        rule_type: type,
        field_name: field,
        source_pattern: src,
        target_value: tgt,
        scope,
        priority: pri,
        company_id: companyId,
        company_ids: companyIds,
      }),
    });
    _allRules.unshift(created);
    closeCreateModal();
    renderTable();
    setMsg(document.getElementById("pageMessage"), "Rule created.", "success");
  } catch (err) {
    setMsg(document.getElementById("createMessage"), "Create failed: " + (err.message || "unknown error"), "error");
  } finally { btn.disabled = false; }
});

// ── Filters ───────────────────────────────────────────────────────────────────
document.getElementById("companyFilter").addEventListener("change", loadRules);
document.getElementById("scopeFilter" ).addEventListener("change", loadRules);
document.getElementById("statusFilter").addEventListener("change", renderTable);
document.getElementById("searchInput" ).addEventListener("input",  renderTable);
document.getElementById("refreshBtn"  ).addEventListener("click",  loadRules);

document.addEventListener("keydown", e => {
  if (e.key === "Escape") {
    closeEditModal();
    closeCreateModal();
  }
});

// ── Init ──────────────────────────────────────────────────────────────────────
(async () => {
  await detectAdminRole();
  await loadCompanies();
  await loadRules();
})();
